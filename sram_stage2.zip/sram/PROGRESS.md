# Progress

**Phase:** all phases done. Deliverables are `REPORT.md`, `docs/EXPLAIN.md`, `docs/VIVA_QA.md` and `plots/`.

## Passed (evidence in `results/`)
- Phase 0: PDK CHECK PASS, read SNM 375 mV, hold 714 mV, write trip 654 mV, smoke 0 errors, `cell6t` 0 DRC.
- Phases 1 to 4: 50 cells 0 DRC errors. LVS 15 of 15 match, including `sram_top`: 2,136 merged devices, 793 nets, no property errors.
- Phase 5, final layout: full test at 200 MHz, 265 reads, 0 errors. Fmax 454.5 MHz (2.2 ns pass, 2.1 ns fail). Core 4.90 pJ write, 4.56 pJ read. Leakage 867 nW.
- Schematic rerun on the same PDK: full test 0 errors, Fmax 769 MHz, core 2.39 / 2.28 pJ, leakage 146 nW.

## Open problems
- Only TT was simulated. No corners.
- Fmax comes from 41 random reads. The full test passed at 200 MHz only.
- `extresist` reached only 8 of 662 nets, so no chip-wide wire resistance. WL poly R is added by script.
- Skew along `clk_ff` is calculated, and the clock is a centre-fed trunk rather than an H-tree.
- Single via stacks on supplies. Not checked for electromigration or IR drop.
- ESD clamps are 16 um2 diodes with no HBM/CDM check.
- Post-layout leakage is about 6 times schematic. Cause not isolated.

## Unanswered
- Stage 2 deadline, and what the examiners asked at the Stage 1 demo.

## How to rebuild
See section 13 of `REPORT.md`.

## Second prompt (2026-11-10): additions
### Xschem schematics: done
- `gen/mk_xschem.py` writes `xschem/*.sch` and `*.sym` from `cells/cells.sp` and the `gen_sram.py` top netlist: 20 cells (each size variant of inv/nand2 is its own cell), `sram256` top level, and the `tb_bitcell` testbench. Connections use net labels.
- Check (`xschem/check.sh`): Xschem netlists each schematic, and netgen compares it with a flat reference from `cells.sp`. Result `xschem/check_result.txt`: 21 of 21 match uniquely with no property errors, `sram256` 2,263 devices. Negative tests: a wrong W (0.84 for 0.63) gave property errors, and a label short gave a device mismatch, so the check does fail when it should.
- Testbench simulated from the Xschem netlist (`xschem/tb_bitcell_result.txt`): Q = 0.000 V after write 0 and after the read, 1.800 V after write 1 and after the read.
- PNGs: `plots/xschem_*.png`. Taken as GUI screenshots on a virtual display, because Xschem's batch PNG export hung and its headless SVG export came out blank.

### Clock tree: done
- `gen/clocktree.py` builds `clk_ff`, `clkb` and `pcb` as distributed RC from the layout geometry, with real cells as loads. It compares four topologies; results are in `results/clocktree/clocktree.txt` and `.json`, plot `plots/10_clock_tree_arrival.png`.
- As built: array skew 0.26 / 0.60 / 0.18 ps; all-sink skew 0.26 / 2.10 / 2.37 ps; clock energy 1.186 pJ per cycle (0.847 mW at 714 MHz). A binary tree reaches 0 ps array skew but costs 1.364 pJ. The layout is not re-routed; the reason is in REPORT section 10.
- `SRAM_CTREE=1` puts the RC trees into `gen_sram.py`. Smoke at 200 MHz: 0/0 errors. Random traffic at 714 MHz: 0/0 errors (`results/clocktree/ct_*.res.json`).

### Docs: done
- `docs/DEMO.md`: live demo steps. `./eda-gui` shows windows via WSLg; the display test passed and the batch Magic DRC demo was verified (0 errors, then 1 met1.1 error). The KLayout and Xschem GUI steps were not clicked through by me.
- `docs/VIVA_QA.md`: 30 questions. `REPORT.md`: Xschem and clock tree sections added.
